<template>
    <div>
        <iv-visualisation :title="projectName">
            <div style="margin:5vh;">
                <div v-show="displaysplot=='disp1'"><h3 style="margin-left:5vh;">2DOF System: Time-History</h3></div>
                <div v-show="displaysplot=='frf'"><h3 style="margin-left:5vh;">2DOF System: FRF</h3></div>
                <!-- <h5 style="margin-left:5vh;">Displacement response for First & Second Natural Frequencies and Combined Mode Response</h5> -->
                <div style="margin:0vh;" id="flexContainer">
                    <div id="innerFlex1">
                        <div v-show="displaysplot=='disp1'" id='graph' style="width:100%"></div>
                        <div v-show="displaysplot=='disp1'" id='graph2' style="width:100%"></div>
                        <div v-show="displaysplot=='disp1'" id='graph3' style="width:100%"></div>
                        <div v-show="displaysplot=='frf'" id='graph7' style="width:100%"></div>
                        <!-- <div v-show="displaysplot=='frf'" id='graph8' ></div> -->
                    </div>
                    <div id="innerFlex2">
                        <div v-show="displaysplot=='disp1'" id='graph4' ></div>
                        <div v-show="displaysplot=='disp1'" id='graph5' ></div>
                        <div v-show="displaysplot=='disp1'" id='graph6' ></div>
                        <div v-show="displaysplot=='frf'" id='graph9' ></div>
                        <!-- <div v-show="displaysplot=='frf'" id='graph10' ></div> -->
                    </div>
                </div>

                <div style="margin:20px;" v-show="lightlyDamped">
                    <!-- {{ solnText }} -->
                    <br>
                    <strong>System Parameters:</strong> 
                    <br>
                    First Natural Frequency, ω<sub>n</sub> (rad/s): {{ f1 }} rad/s
                    <br>
                    Second Natural Frequency, ω<sub>n</sub> (rad/s): {{ f2 }} rad/s
                </div>

                <div style="margin:20px;" v-show="!lightlyDamped">
                    <!-- {{ solnText }} -->
                    <br><br>
                    <strong>System Parameters:</strong>
                    <br>
                    First Natural Frequency, ω<sub>n</sub> (rad/s): {{ f1 }} rad/s
                    <br>
                    Second Natural Frequency, ω<sub>n</sub> (Hz): {{ f2 }} Hz
                    <br>
                    Maximum displacement (m): {{ maxAmp }} m
                </div>
            </div>

            <template #hotspots>
                <iv-pane position="left" width="20">
                    <iv-sidebar-content style="font-size:12px" nextText="SDOF" previousText="Vib. Iso.">
                        <iv-sidebar-section title="2DOF">
                            <img src="./assets/systempicforimpvis.png" style="width:16vw;">
                            <br>
                            <p style="font-size:14px" class="small">A 2DOF system consists of two masses connected by a spring. A combination of up to 5 springs is sufficient to represent any valid 2DOF system. The system may be completely described by the displacements of the masses, x1 and x2. The equations of motion for the system are as follows.</p>
                            <img src="./assets/2dofEoM.png" style="width:16vw;">
                            <p style="font-size:14px" class="small">Explore the motion of a 2DOF system by inputting your desired parameters, including initial displacement of the masses. You can specify up to 5 spring constants - only the spring constant connecting the 2 masses, k2, must be specified, in order to form a 2DOF system. Observe the FRF and select between viewing the receptance, mobility and accelerance as desired.</p>
                            
                        </iv-sidebar-section>
                    </iv-sidebar-content>
                </iv-pane>

                <iv-pane position="right" :allowResize="false">
                    <div style="margin-top:0px; padding:20px;" >
                        
                        <h5>Desired Plots</h5>
                        
                        <form>
                            <p style="font-size:15px" class="small"><input type="radio" id="disp11" value="disp1" v-model="displaysplot" checked>
                            <label for="disp11">Time-Histories</label>
                            <br>
                            <input type="radio" id="h11" value="frf" v-model="displaysplot">
                            <label for="h11">FRF</label></p>
                            
                        </form>
                        
                        <h5>Desired Response</h5>
                        <form>
                            <p style="font-size:15px" class="small"><input type="radio" id="plot1" value="1" v-model="displaysplot2" @change="update" checked>
                            <label for="plot1">Displacement (Receptance)</label>
                            <br>
                            <input type="radio" id="plot2" value="2" v-model="displaysplot2" @change="update">
                            <label for="plot2">Velocity (Mobility)</label>
                            <br>
                            <input type="radio" id="plot3" value="3" v-model="displaysplot2" @change="update">
                            <label for="plot3">Acceleration (Accelerance)</label></p>
                            
                        </form>
                        <!-- <form>
                            <input type="radio" id="disp11" value="disp1" v-model="displaysplot" checked>
                            <label for="disp11">x<sub>1</sub> Displacement: Mode 1</label>
                            <br>
                            <input type="radio" id="disp12" value="disp2" v-model="displaysplot">
                            <label for="disp12">x<sub>1</sub> Displacement: Mode 2</label>
                            <br>
                            <input type="radio" id="disp13" value="disp3" v-model="displaysplot">
                            <label for="disp13">x<sub>1</sub> Overall Displacement</label>
                            <br>
                            <input type="radio" id="disp21" value="disp4" v-model="displaysplot">
                            <label for="disp21">x<sub>2</sub> Displacement: Mode 1</label>
                            <br>
                            <input type="radio" id="disp22" value="disp5" v-model="displaysplot">
                            <label for="disp22">x<sub>2</sub> Displacement: Mode 2</label>
                            <br>
                            <input type="radio" id="disp23" value="disp6" v-model="displaysplot">
                            <label for="disp23">x<sub>2</sub> Overall Displacement</label>
                            <br>
                        </form>

                        <form>
                            <input type="radio" id="h11" value="frf11" v-model="displaysplot2" checked>
                            <label for="h11">FRF: Excitation 1, Response 1</label>
                            <br>
                            <input type="radio" id="h12" value="frf12" v-model="displaysplot2">
                            <label for="h12">FRF: Excitation 1, Response 2</label>
                            <br>
                            <input type="radio" id="h21" value="frf21" v-model="displaysplot2">
                            <label for="h21">FRF: Excitation 2, Response 1</label>
                            <br>
                            <input type="radio" id="h22" value="frf22" v-model="displaysplot2">
                            <label for="h22">FRF: Excitation 2, Response 2</label>
                            <br>
                        </form> -->

                        <!-- <label>Displacement</label>
                        <br>
                        <input v-model="dispx" @change="update">
                        <br> -->
                        
                        <!-- <div style="width:100%;overflow:hidden"><h5 style="width:150px;float:left">System Parameters</h5> <iv-hover-text defaultText="Enter your system parameters here" hoverText="?" style="margin-left:170px;margin-top:25px" :clickInsteadOfHover=true>?</iv-hover-text></div> -->
                        <h5>System Parameters</h5>
                        <p style="font-size:15px" class="big"><label>Mass, m<sub>1</sub> (kg)</label>
                        <br>
                        <input v-model="mass1" @change="update">
                        <br>

                        <label>Mass, m<sub>2</sub> (kg)</label>
                        <br>
                        <input v-model="mass2" @change="update">
                        <br>

                        <label>Spring Constant, k<sub>1</sub> (N/m)</label>
                        <br>
                        <input maxlength="6" min="10" v-model="springConst1"  @change="update">
                        <br>

                        <label>Spring Constant, k<sub>2</sub> (N/m)</label>
                        <br>
                        <input maxlength="6" minlength="2" v-model="springConst2"  @change="update">
                        <br>

                        <label>Spring Constant, k<sub>3</sub> (N/m)</label>
                        <br>
                        <input maxlength="6" minlength="2" v-model="springConst3"  @change="update">
                        <br>

                        <label>Spring Constant, k<sub>4</sub> (N/m)</label>
                        <br>
                        <input maxlength="6" minlength="2" v-model="springConst4"  @change="update">
                        <br>

                        <label>Spring Constant, k<sub>5</sub> (N/m)</label>
                        <br>
                        <input maxlength="6" minlength="2" v-model="springConst5"  @change="update">
                        <br></p>

                        <h5>Initial Conditions</h5>
                        <p style="font-size:15px" class="small"><label>Initial Displacement, x<sub>1</sub> (m)</label>
                        <br>
                        <input v-model="initDisp1"  @change="update">
                        <br>
                        <label>Initial Displacement, x<sub>2</sub> (m)</label>
                        <br>
                        <input v-model="initDisp2"  @change="update"></p>

                    </div>
                </iv-pane>
                
                <!-- <iv-fixed-hotspot position="topright" style="width:300px; z-index:2" transparent>
                    
                </iv-fixed-hotspot> -->
            </template>

        
        </iv-visualisation>
    </div>
</template>
<script>
import Plotly from 'plotly.js/dist/plotly.min.js'; // eslint-disable-line no-unused-vars
//import math from 'math.js';
import math from 'mathjs/lib/browser/math.js'
//import danfo from 'danfojs/dist/danfojs-browser/src/core/series.js'
//import * as dfd from "danfojs"
//import { Series } from "danfojs"

export default {
    name:"App",
    data(){
        return {
            projectName: 'Vibrations App - 2DOF',
            mass1: 20,
            mass2: 1,
            //mass3: 1,
            //dampRatio: 0.1,
            initDisp1:0.05,
            initDisp2:0,
            //timeSpan:2,
            springConst1: 10000,
            springConst2: 1000,
            springConst3: 0,
            springConst4: 0,
            springConst5: 10000,
            //dampCoeff:6.325,
            //numPoints:1000,
            updatePlot: true,
            f1: 0,
            f2: 0,
            wd: 31,
            wdHz: 5,
            maxAmp: 0.1,
            solnText: "This is an Under Damped Solution",
            showText: true,
            showCoeff: false,
            lightlyDamped: true,
            dispx: 1,
            displaysplot: "disp1",
            displaysplot2: "1"
        }
    },
    methods: {
        update(){
            let temp2 = this.springConst2;
            //console.log('mass = ', this.mass1);
            if(this.mass1 <= 0){
                this.mass1 = 1;
                window.alert("Mass must be greater than 0.");
            }
            else if(this.mass2 <= 0){
                this.mass2 = 1;
                window.alert("Mass must be greater than 0.");
            }
            else if(this.mass3 <= 0){
                this.mass3 = 1;
                window.alert("Mass must be greater than 0.");
            }
            else if((this.springConst2 >= 10000 && this.springConst2 <= 40000)) {
                temp2 = this.springConst2;
                this.springConst2 = temp2;
            }
            else if((this.springConst2 >= 100000 && (0 < this.springConst1 < 10 || 0 < this.springConst5 < 10))) {
                 window.alert("Warning: the ratio between your spring constants 2 and 1+5 is very high - errors in the FRF phase plots are likely to occur. Please use a lower value for k2.");
                
            }
            else if((this.springConst2 <= 10 && (this.springConst1 >= 10000 || this.springConst5 >= 10000)) || 
                    (this.springConst2 <= 100 && (this.springConst1 >= 100000 || this.springConst5 >= 100000))) {
                window.alert("Warning: the ratio between your spring constants 2 and 1+5 is very high - errors in the FRF phase plots are likely to occur. Please use lower values for k1/k5 or a higher value for k2.");
                
            }
            else if(((this.springConst2 > 10000 && (0 < this.springConst1 < 10 || 0 < this.springConst5 < 10)) || 
                    (this.springConst2 >= 100000 && (0 < this.springConst1 < 100 || 0 < this.springConst5 < 100))) && (this.springConst2 - this.springConst1 > 9000 || this.springConst2 - this.springConst5 > 9000)  ) {
                window.alert("Warning: the ratio between your spring constants 2 and 1+5 is very high - errors in the FRF phase plots are likely to occur. Please use higher values for k1/k5 or a lower value for k2.");
                
            }
            else if((this.springConst2 <= 10 && (this.springConst3 >= 10000 || this.springConst4 >= 10000)) || 
                    (this.springConst2 <= 100 && (this.springConst3 >= 100000 || this.springConst4 >= 100000)) ) {
                window.alert("Warning: the ratio between your spring constants 2 and 3+4 is very high - errors in the FRF phase plots are likely to occur. Please use lower values for k3/k4 or a higher value for k2.");
                
            }
            else if(((this.springConst2 > 10000 && (0 < this.springConst3 < 10 || 0 < this.springConst4 < 10)) || 
                    (this.springConst2 >= 100000 && (0 < this.springConst3 < 100 || 0 < this.springConst4 < 100))) && (this.springConst2 - this.springConst1 > 9000 || this.springConst2 - this.springConst5 > 9000)  ) {
                window.alert("Warning: the ratio between your spring constants 2 and 3+4 is very high - errors in the FRF phase plots are likely to occur. Please use higher values for k3/k4 or a lower value for k2.");
                
            }
            /* else if((this.springConst3+this.springConst4)/this.springConst2 >= 1000 || this.springConst2/(this.springConst3+this.springConst4) >= 1000) {
                if (this.springConst3 != 0 || this.springConst4 != 0 ){
                    // this.springConst1 = 10000;
                    // this.springConst2 = 1000;
                    // this.springConst3 = 0;
                    // this.springConst4 = 0;
                    // this.springConst5 = 10000;
                    window.alert("Warning: the ratio between your spring constants 2 and 1+5 is very high - please use lower ratios for better performance.");
                }
            } */
            else if(this.mass1/this.mass2 >= 5000 || this.mass2/this.mass1 >= 5000){
                this.mass1 = 20;
                this.mass2 = 1;
                window.alert("Please do not use mass ratios above 5000.");
            }
            else if(this.springConst2 <= 0){
                window.alert("The spring connecting the masses must always have a spring constant greater than 0 in order to have a 2-degree-of-freedom system.");
                this.springConst2 = 1000;
            }
            else if(this.timeSpan <= 0){
                window.alert("Time span must be greater than 0.");
                this.springConst = 1000;
            }
            else if(this.numPoints <= (2*this.wnHz * this.timeSpan)){
                window.alert(`Please ensure your sampling frequency (Number of Points/Time Span), ${this.numPoints/this.timeSpan} Hz, is well above double the natural frequency of the system, ${this.wnHz} Hz. This is to prevent aliasing from occuring. We recommend increasing the number of points beyond ${4*this.wnHz * this.timeSpan} points.`);
                this.numPoints = (4*this.wnHz * this.timeSpan);
            }
            else{
                this.updatePlot = true;
            }
            
        },
/*         updateradio(){
            console.log(this.displaysplot);
        }, */
    },
    mounted(){

        let vm = this; // eslint-disable-line no-unused-vars

        let layout = {
            autosize: true,
            title: "x<sub>1</sub> Displacement: First Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Displacement, x<sub>1</sub> (m)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout2 = {
            title: "x<sub>2</sub> Displacement: First Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Displacement, x<sub>2</sub> (m)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout3 = {
            title: "x<sub>1</sub> Displacement: Second Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Displacement, x<sub>1</sub> (m)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout4 = {
            title: "x<sub>2</sub> Displacement: Second Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Displacement, x<sub>2</sub> (m)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout5 = {
            title: "x<sub>1</sub> Overall Displacement",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Displacement, x<sub>1</sub> (m)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout6 = {
            title: "x<sub>2</sub> Overall Displacement",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Displacement, x<sub>2</sub> (m)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };
        
        // 
        let layout11 = {
            autosize: true,
            title: "x&#775;<sub>1</sub> Velocity: First Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Velocity, x&#775;<sub>1</sub> (m/s)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout21 = {
            title: "x&#775;<sub>2</sub> Velocity: First Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Velocity, x&#775;<sub>2</sub> (m/s)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout31 = {
            title: "m<sub>1</sub> Velocity: Second Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Velocity, x&#775;<sub>1</sub> (m/s)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout41 = {
            title: "m<sub>2</sub> Velocity: Second Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Velocity, x&#775;<sub>2</sub> (m/s)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout51 = {
            title: "m<sub>1</sub> Overall Velocity",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Velocity, x&#775;<sub>1</sub> (m/s)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout61 = {
            title: "m<sub>2</sub> Overall Velocity",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Velocity, x&#775;<sub>2</sub> (m/s)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

         
        let layout12 = {
            autosize: true,
            title: "&#7821;<sub>1</sub> Acceleration: First Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Acceleration, &#7821;<sub>1</sub> (m/s<sup>2</sup>)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout22 = {
            title: "&#7821;<sub>2</sub> Acceleration: First Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Acceleration, &#7821;<sub>2</sub> (m/s<sup>2</sup>)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout32 = {
            title: "&#7821;<sub>1</sub> Acceleration: Second Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Acceleration, &#7821;<sub>1</sub> (m/s<sup>2</sup>)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout42 = {
            title: "&#7821;<sub>2</sub> Acceleration: Second Natural Frequency",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Acceleration, &#7821;<sub>2</sub> (m/s<sup>2</sup>)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout52 = {
            title: "&#7821;<sub>1</sub> Overall Acceleration",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Acceleration, &#7821;<sub>1</sub> (m/s<sup>2</sup>)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        let layout62 = {
            title: "&#7821;<sub>2</sub> Overall Acceleration",
            xaxis: {title:"Time (sec)"},
            yaxis: {title:"Acceleration, &#7821;<sub>2</sub> (m/s<sup>2</sup>)"},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        };

        /* let layout7 = {
            title: "FRF: Excitation 1",
            xaxis: {title:"Excitation Frequency (rad/s)"},
            yaxis: {title:"Frequency Response, x/F (m/N)",
                    type: 'log',
                    autorange: true},
            showlegend: true,
            legend: {
                orientation: 'h',
                xanchor: "centre",
                x: 0,
                y: 1.1
            },
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        }; */

        /* let layout8 = {
            title: "FRF: Excitation 1, Response 2",
            xaxis: {title:"Excitation Frequency (rad/s)"},
            yaxis: {title:"Frequency Response, x/F (m/N)",
                    type: 'log',
                    autorange: true},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        }; */

        let layout7 = {
            grid: {rows: 2, columns: 1, pattern: 'independent'},
            title: "FRF: Excitation on m1",
            xaxis: {showticklabels: false},
            yaxis: {title:"Receptance, x/F (m/N)",
                    type: 'log',
                    autorange: true},
            xaxis2: {title:"Excitation Frequency (rad/s)"},
            yaxis2: {title:"Phase (degrees)"},
            
            showlegend: true,
            legend: {
                orientation: 'h',
                xanchor: "centre",
                x: 0,
                y: -0.2,
            },
            font: {
                color: "#003E74",
                weight: 800,
                size: 10,
          }
        };

        let layout9 = {
            grid: {rows: 2, columns: 1, pattern: 'independent'},
            title: "FRF: Excitation on m2",
            xaxis: {showticklabels: false},
            yaxis: {title:"Receptance, x/F (m/N)",
                    type: 'log',
                    autorange: true},
            xaxis2: {title:"Excitation Frequency (rad/s)"},
            yaxis2: {title:"Phase (degrees)"},
            
            showlegend: true,
            legend: {
                orientation: 'h',
                xanchor: "centre",
                x: 0,
                y: -0.2,
            },
            font: {
                color: "#003E74",
                weight: 800,
                size: 10,
          }
        };
        
        let layout71 = {
            grid: {rows: 2, columns: 1, pattern: 'independent'},
            title: "FRF: Excitation on m1",
            xaxis: {showticklabels: false},
            yaxis: {title:"Mobility, x&#775;/F (m/Ns)",
                    type: 'log',
                    autorange: true},
            xaxis2: {title:"Excitation Frequency (rad/s)"},
            yaxis2: {title:"Phase (degrees)"},
            
            showlegend: true,
            legend: {
                orientation: 'h',
                xanchor: "centre",
                x: 0,
                y: -0.2,
            },
            font: {
                color: "#003E74",
                weight: 800,
                size: 10,
          }
        };

        let layout91 = {
            grid: {rows: 2, columns: 1, pattern: 'independent'},
            title: "FRF: Excitation on m2",
            xaxis: {showticklabels: false},
            yaxis: {title:"Mobility, x&#775;/F (m/Ns)",
                    type: 'log',
                    autorange: true},
            xaxis2: {title:"Excitation Frequency (rad/s)"},
            yaxis2: {title:"Phase (degrees)"},
            
            showlegend: true,
            legend: {
                orientation: 'h',
                xanchor: "centre",
                x: 0,
                y: -0.2,
            },
            font: {
                color: "#003E74",
                weight: 800,
                size: 10,
          }
        };

        let layout72 = {
            grid: {rows: 2, columns: 1, pattern: 'independent'},
            title: "FRF: Excitation on m1",
            xaxis: {showticklabels: false},
            yaxis: {title:"Accelerance, &#7821;/F (m/Ns<sup>2</sup>)",
                    type: 'log',
                    autorange: true},
            xaxis2: {title:"Excitation Frequency (rad/s)"},
            yaxis2: {title:"Phase (degrees)"},
            
            showlegend: true,
            legend: {
                orientation: 'h',
                xanchor: "centre",
                x: 0,
                y: -0.2,
            },
            font: {
                color: "#003E74",
                weight: 800,
                size: 10,
          }
        };

        let layout92 = {
            grid: {rows: 2, columns: 1, pattern: 'independent'},
            title: "FRF: Excitation on m2",
            xaxis: {showticklabels: false},
            yaxis: {title:"Accelerance, &#7821;/F (m/Ns<sup>2</sup>)",
                    type: 'log',
                    autorange: true},
            xaxis2: {title:"Excitation Frequency (rad/s)"},
            yaxis2: {title:"Phase (degrees)"},
            
            showlegend: true,
            legend: {
                orientation: 'h',
                xanchor: "centre",
                x: 0,
                y: -0.2,
            },
            font: {
                color: "#003E74",
                weight: 800,
                size: 10,
          }
        };

        /* let layout10 = {
            title: "FRF: Excitation 2, Response 2",
            xaxis: {title:"Excitation Frequency (rad/s)"},
            yaxis: {title:"Frequency Response, x/F (m/N)",
                    type: 'log',
                    autorange: true},
            font: {
                color: "#003E74",
                weight: 800,
                size: 10
          }
        }; */

        let config = {responsive: false};

        function phaseplot(H, omega){
            
            let sortedH = [];
            for (let i = 0; i < H.length; i++){
                sortedH.push(H[i]);
            }
            sortedH.sort(function(a, b){return b-a});
            //sortedH = Math.argsort(H)[::-1]
            //console.log(sortedH)
            let omega1 = 0;
            let omega2 = 0;
            let ResFound = 0;

            for (let i = 1; i < omega.length-1; i++){
                if ((Math.abs(H[i]) > Math.abs(H[i-1])) && (Math.abs(H[i]) > Math.abs(H[i+1]))){
                    if (ResFound == 0) {
                        omega1 = i; // eslint-disable-line no-unused-vars
                        ResFound = 1;
                    }
                    else {
                        omega2 = i; // eslint-disable-line no-unused-vars
                    }
                }
                
            }

/*             for (let i = 0; i < omega.length; i++){
                if (H[i] == sortedH[0] || H[i] == sortedH[1]){
                    if (ResFound == 0) {
                        omega1 = i; // eslint-disable-line no-unused-vars
                        ResFound = 1;
                    }
                    else {
                        omega2 = i; // eslint-disable-line no-unused-vars
                    }
                }
                
            }     */
            let antindex = 0;
            let antires = 0;
            for (let i = 0; i < omega1-1; i++){
                if (((H[i] >= 0) && (0 >= H[i + 1])) || ((H[i] <= 0) && (0 <= H[i + 1]))){
                    antires = 1; 
                    //let antif = omega[i];
                    antindex = i; 
                }
            }        
            for (let i = omega1+1; i < omega2-1; i++){
                if (((H[i] >= 0) && (0 >= H[i + 1])) || ((H[i] <= 0) && (0 <= H[i + 1]))){
                    antires = 1; 
                    //let antif = omega[i];
                    antindex = i; 
                }
            }        
            for (let i = omega2+1; i < omega.length - 2; i++){
                if (((H[i] >= 0) && (0 >= H[i + 1])) || ((H[i] <= 0) && (0 <= H[i + 1]))){
                    antires = 1;
                    //let antif = omega[i];
                    antindex = i; 
                }
            }
            let phase = 0;
            //bode_phase = np.zeros(len(omega))

            let bodephase = [];
            for (let i = 0; i < omega.length; i++){
                bodephase.push(0);
            }
            
            for (let i = 0; i < omega.length + 2; i++){
                if (i == omega1){
                    phase -= 180;
                }
                else if (i == omega2){
                    phase -= 180;
                }
                else if (antires == 1){
                    if (i == antindex){
                        phase += 180;
                    }
                }
                bodephase[i] = phase;
            }
            return bodephase        
        }

        function SDOF_solver(){
            
            let m1 = Number(vm.mass1);
            let m2 = Number(vm.mass2);
            let k1 = Number(vm.springConst1);
            let k2 = Number(vm.springConst2);
            let k3 = Number(vm.springConst3);
            let k4 = Number(vm.springConst4);
            let k5 = Number(vm.springConst5);
            let x1 = Number(vm.initDisp1);
            let x2 = Number(vm.initDisp2);
            let v1 = 0;
            let v2 = 0;
            let disp = Number(vm.dispx)
            let disp2 = vm.displaysplot2;
            //console.log(k1,k2,k3,k4,k5)
            //let tend = vm.timeSpan;
            //let n = vm.numPoints;
            //let x = [];
            //let A, B;

            let a = m1*m2;
            let b = -m1 * (k2 + k3 + k4) - m2 * (k1 + k2 + k5)
            let c = (k1 + k2 + k5) * (k2 + k3 + k4) - k2**2

            let wn1sqrd = (-b - Math.sqrt(b**2 - 4*a*c))/(2 * a)
            let wn2sqrd = (-b + Math.sqrt(b**2 - 4*a*c))/(2 * a)
            let fmin = Math.sqrt(wn1sqrd)
            let fmax = Math.sqrt(wn2sqrd)
            //let wn = Math.sqrt(k / m);  // Natural Freq of spring mass system
            //let wnHz = wn/(2*Math.PI);    // Natural freq in Hz
            //let wd, wdHz;
            vm.f1 = Math.round(fmin*10) / 10
            vm.f2 = Math.round(fmax*10) / 10
            
            //let t = [];
            
            // Calculate mode shapes
            let beta1x = (k1 + k2 + k5 - m1 * fmin ** 2) / k2
            let beta2x = (k1 + k2 + k5 - m1 * fmax ** 2) / k2

            // Use analytic expressions to calculate phi1, phi2, A1 and A2
            let phi1 = -1 * Math.atan((fmin * (x2 - beta2x * x1))/(v2 - beta2x * v1))
            let phi2 = -1 * Math.atan((fmax * (x2 - beta1x * x1))/(v2 - beta1x * v1))
            let A1 = (x2 - beta2x * x1)/((beta1x - beta2x)*(Math.sin(-phi1)))
            let A2 = (x2 - beta1x * x1)/((beta2x - beta1x)*(Math.sin(-phi2)))
            //console.log(A1, phi1, fmin, wn1sqrd)

            // An exceptional case where only k2 is used (i.e. becomes an SDOF system) phi1 must be set to 0 to avoid errors
            if (k1 == 0 && k3 == 0 && k4 == 0 & k5 == 0){
                phi1 = 0
            }

            // Generate values for time on x-axis
            let dt = 1 / ((20 * fmax) / (2 * Math.PI))
            let t = []
            
            for (let i = 0; i < 200; i++){
                t.push(i*dt)
            }
            //console.log(t.length)

            let x1sol = []
            let x2sol = []
            let x1solA1 = [] 
            let x2solA1 = []
            let x1solA2 = []
            let x2solA2 = []
            let v1sol = []
            let v2sol = []
            let v1solA1 = [] 
            let v2solA1 = []
            let v1solA2 = []
            let v2solA2 = []
            let a1sol = []
            let a2sol = []
            let a1solA1 = [] 
            let a2solA1 = []
            let a1solA2 = []
            let a2solA2 = []
            
            // Initialise arrays to store values of displacement, velocity and acceleration time histories
            for (let i = 0; i < t.length; i++){
                x1sol.push(0)
                x2sol.push(0)
                x1solA1.push(0)
                x2solA1.push(0)
                x1solA2.push(0)
                x2solA2.push(0)
                v1sol.push(0)
                v2sol.push(0)
                v1solA1.push(0)
                v2solA1.push(0)
                v1solA2.push(0)
                v2solA2.push(0)
                a1sol.push(0)
                a2sol.push(0)
                a1solA1.push(0)
                a2solA1.push(0)
                a1solA2.push(0)
                a2solA2.push(0)
            }

            // Solve for displacement of m1 and m2 with time, along with velocity
            for (let i = 0; i < t.length; i++){
                x1solA1[i] = A1 * Math.sin(fmin * t[i] - phi1)
                x2solA1[i] = beta1x * A1 * Math.sin(fmin * t[i] - phi1)
                x1solA2[i] = A2 * Math.sin(fmax * t[i] - phi2)
                x2solA2[i] = beta2x * A2 * Math.sin(fmax * t[i] - phi2)
                x1sol[i] = x1solA1[i] + x1solA2[i]
                x2sol[i] = x2solA1[i] + x2solA2[i]

                v1solA1[i] = fmin * A1 * Math.sin(fmin * (t[i] + (Math.PI/(2*fmin))) - phi1)
                v2solA1[i] = fmin * beta1x * A1 * Math.sin(fmin * (t[i] + (Math.PI/(2*fmin))) - phi1)
                v1solA2[i] = fmax * A2 * Math.sin(fmax * (t[i] + (Math.PI/(2*fmax))) - phi2)
                v2solA2[i] = fmax * beta2x * A2 * Math.sin(fmax * (t[i] + (Math.PI/(2*fmax))) - phi2)
                v1sol[i] = v1solA1[i] + v1solA2[i]
                v2sol[i] = v2solA1[i] + v2solA2[i]

                if (phi1==0){
                    x1sol[i] = x1solA2[i]
                    x2sol[i] = x2solA2[i]
                    v1sol[i] = v1solA2[i]
                    v2sol[i] = v2solA2[i]
                }
                //console.log(x1solA1[i])

                a1solA1[i] = - (fmin**2) * A1 * Math.sin(fmin * t[i] - phi1)
                a2solA1[i] = - (fmin**2) * beta1x * A1 * Math.sin(fmin * t[i] - phi1)
                a1solA2[i] = - (fmax**2) * A2 * Math.sin(fmax * t[i] - phi2)
                a2solA2[i] = - (fmax**2) * beta2x * A2 * Math.sin(fmax * t[i] - phi2)
                a1sol[i] = a1solA1[i] + a1solA2[i]
                a2sol[i] = a2solA1[i] + a2solA2[i]
            }

            let psi = [[1/beta1x, 1/beta2x],
                       [1, 1]]
            let psitrans = math.transpose(psi)
            let M = [[m1, 0],
                     [0, m2]]
            let mr = math.multiply(psitrans, M, psi)
            // Invert mr to get mr^(-1)
            let invmr = math.inv(mr)
            //let mrmin12 = math.pow(temp, 0.5)
            // Find eigenvalues and eigenvectors of inverse of mr
            let eig = math.eigs(invmr)
            let eigval = eig.values
            let eigvec = eig.vectors
            let inveigvec = math.inv(eigvec)
            // Form the square root of the eigenvalue matrix
            let sqrteigval = [[Math.sqrt(eigval[0]), 0],
                              [0, Math.sqrt(eigval[1])]]
            // obtain mr^(-1/2) by multiply eigvec, sqrteigval and inveigvec
            let mrmin12 = math.multiply(eigvec, sqrteigval, inveigvec)
            let phi = math.multiply(psi, mrmin12)
            //console.log(phi)

            // Generate values for excitation frequency on x-axis
            let dfexc = 0.05
            let omega = []

            if (m1/m2 >= 300 || m2/m1 >= 300 || k2/(k1+k5)<=0.01 || (k1+k5)/k2<=0.01 || k2/(k3+k4)<=0.01 || (k3+k4)/k2<=0.01 ){
                dfexc = 0.01
            }

            if ((k1 > 800 && k3 > 800 && k5 > 800) || (k1 > 800 && k4 > 800 && k5 > 800) || (k3 > 800 && k4 > 800 && k5 > 800) || (k3 > 800 && k4 > 800 && k1 > 800)){
                dfexc = 0.01
            }

            if (m1/m2 >= 1400 || m2/m1 >= 1400 || k2/(k1+k5)<=0.001 || (k1+k5)/k2<=0.001 || k2/(k3+k4)<=0.001 || (k3+k4)/k2<=0.001 ){
                dfexc = 0.005
            }

            if ((k1 >= 5000 || k5 >= 5000) && (k4 >= 5000 || k3 >= 5000)) {
                dfexc = 0.005
            }

            if (m1/m2 >= 4000 || m2/m1 >= 4000 || k2/(k1+k5)<=0.0001 || (k1+k5)/k2<=0.0001 || k2/(k3+k4)<=0.0001 || (k3+k4)/k2<=0.0001 ){
                dfexc = 0.002
            }

            if ((k1 >= 50000 || k5 >= 50000) && (k4 >= 50000 || k3 >= 50000)) {
                dfexc = 0.002
            }
            
            let excmin = Math.round(fmin-10)
            if (excmin < 0){
                excmin = 0
            }
            for (let i = excmin; i < Math.round(fmax+10); i+=dfexc){
                omega.push(i)
            }
            //console.log(omega)

            // Generate empty arrays for FRF plots
            let H0 = []
            let H1 = []
            let H2 = [] 
            let H3 = []
            let vH0 = []
            let vH1 = []
            let vH2 = [] 
            let vH3 = []
            let aH0 = []
            let aH1 = []
            let aH2 = [] 
            let aH3 = []

            for (let i = 0; i < omega.length; i++){
                H0.push(0)
                H1.push(0)
                H2.push(0)
                H3.push(0)
                vH0.push(0)
                vH1.push(0)
                vH2.push(0)
                vH3.push(0)
                aH0.push(0)
                aH1.push(0)
                aH2.push(0)
                aH3.push(0)
            }

            // Solve for FRF for excitation frequencies in omega
            for (let i = 0; i < omega.length; i++){
                H0[i] = ((phi[0][0] * phi[0][0]) / (wn1sqrd - (omega[i] ** 2))) + ((phi[0][1] * phi[0][1]) / (wn2sqrd - (omega[i] ** 2)))
                H1[i] = ((phi[0][0] * phi[1][0]) / (wn1sqrd - (omega[i] ** 2))) + ((phi[0][1] * phi[1][1]) / (wn2sqrd - (omega[i] ** 2)))
                H2[i] = ((phi[1][0] * phi[0][0]) / (wn1sqrd - (omega[i] ** 2))) + ((phi[1][1] * phi[0][1]) / (wn2sqrd - (omega[i] ** 2)))
                H3[i] = ((phi[1][0] * phi[1][0]) / (wn1sqrd - (omega[i] ** 2))) + ((phi[1][1] * phi[1][1]) / (wn2sqrd - (omega[i] ** 2)))         
                //console.log(x1solA1[i])
            }
            //console.log(phi1);

            // Obtain mobility and accelerance by multiplying by excitation frequency and excitation frequency squared respectively
            for (let i = 0; i < omega.length; i++){
                vH0[i] = omega[i] * H0[i]
                vH1[i] = omega[i] * H1[i]
                vH2[i] = omega[i] * H2[i]
                vH3[i] = omega[i] * H3[i]
                aH0[i] = omega[i]**2 * H0[i]
                aH1[i] = omega[i]**2 * H1[i]
                aH2[i] = omega[i]**2 * H2[i]
                aH3[i] = omega[i]**2 * H3[i]
                //console.log(x1solA1[i])
            }

            let H0Phase = phaseplot(H0, omega)
            let H1Phase = phaseplot(H1, omega)
            let H2Phase = phaseplot(H2, omega)
            let H3Phase = phaseplot(H3, omega)
            let vH0Phase = phaseplot(H0, omega)
            let vH1Phase = []
            let vH2Phase = []
            let vH3Phase = []
            let aH0Phase = []
            let aH1Phase = []
            let aH2Phase = []
            let aH3Phase = []

            for (let i = 0; i < omega.length; i++){
                H0[i] = Math.abs(H0[i])
                H1[i] = Math.abs(H1[i])
                H2[i] = Math.abs(H2[i])
                H3[i] = Math.abs(H3[i])
                //console.log(x1solA1[i])
                vH0[i] = Math.abs(vH0[i])
                vH1[i] = Math.abs(vH1[i])
                vH2[i] = Math.abs(vH2[i])
                vH3[i] = Math.abs(vH3[i])
                aH0[i] = Math.abs(aH0[i])
                aH1[i] = Math.abs(aH1[i])
                aH2[i] = Math.abs(aH2[i])
                aH3[i] = Math.abs(aH3[i])
                vH0Phase[i] = H0Phase[i] + 90
                vH1Phase[i] = H1Phase[i] + 90
                vH2Phase[i] = H2Phase[i] + 90
                vH3Phase[i] = H3Phase[i] + 90
                aH0Phase[i] = H0Phase[i] + 180
                aH1Phase[i] = H1Phase[i] + 180
                aH2Phase[i] = H2Phase[i] + 180
                aH3Phase[i] = H3Phase[i] + 180
            }

            return [t, x1solA1, x2solA1, x1solA2, x2solA2, x1sol, x2sol, omega, H0, H1, H2, 
            H3, disp, H0Phase, H1Phase, H2Phase, H3Phase, disp2, v1solA1, v2solA1, v1solA2, 
            v2solA2, v1sol, v2sol, a1solA1, a2solA1, a1solA2, a2solA2, a1sol, a2sol, vH0, 
            vH1, vH2, vH3, vH0Phase, vH1Phase, vH2Phase, vH3Phase, aH0, aH1, aH2, 
            aH3, aH0Phase, aH1Phase, aH2Phase, aH3Phase]

        }

        let i = 0;
        function update(){
            requestAnimationFrame(update);

            if(vm.updatePlot || i > 10){
                vm.updatePlot = false;
                
                let data = SDOF_solver();
                //console.log(data);

                // Plotting Receptance
                if (data[17] == "1"){
                    
                    Plotly.newPlot('graph', [{
                    title: "x1 Displacement: First Natural Frequency",
                    x : data[0],
                    y : data[1],
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines'
                    }],
                    layout,
                    config
                    )
                    

                    Plotly.newPlot('graph4', [{
                    x : data[0],
                    y : data[2],
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines'
                    }],
                    layout2,
                    config
                    )


                    Plotly.newPlot('graph2', [{
                    x : data[0],
                    y : data[3],
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines'
                    }],
                    layout3,
                    config
                    )

                    Plotly.newPlot('graph5', [{
                    x : data[0],
                    y : data[4],
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines'
                    }],
                    layout4,
                    config
                    )

                    Plotly.newPlot('graph3', [{
                    x : data[0],
                    y : data[5],
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines'
                    }],
                    layout5,
                    config
                    )

                    Plotly.newPlot('graph6', [{
                    x : data[0],
                    y : data[6],
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines'
                    }],
                    layout6,
                    config
                    )

                    Plotly.newPlot('graph7', [{
                    x : data[7],
                    y : data[8],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    name: "Response at m1"
                    },
                    {
                    x : data[7],
                    y : data[9],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Response at m2"
                    },
                    {
                    x : data[7],
                    y : data[13],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 1"
                    },
                    {
                    x : data[7],
                    y : data[14],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(255,127,15)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 2"
                    }],
                    layout7,
                    config
                    )

                    i=0;

                    Plotly.newPlot('graph9', [{
                    x : data[7],
                    y : data[10],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    name: "Response at m1"
                    },
                    {
                    x : data[7],
                    y : data[11],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Response at m2"    
                    },
                    {
                    x : data[7],
                    y : data[15],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 1"
                    },
                    {
                    x : data[7],
                    y : data[16],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(255,127,15)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 2"
                    }],
                    layout9,
                    config
                    )

                    i = 0;
                }
                
                // Plotting Mobility
                if (data[17] == "2"){

                    Plotly.newPlot('graph', [{
                    title: "x1 Displacement: First Natural Frequency",
                    x : data[0],
                    y : data[18],
                    line: {simplify: false, color: 'rgb(152,66,245)'},
                    mode: 'lines'
                    }],
                    layout11,
                    config
                    )
                    

                    Plotly.newPlot('graph4', [{
                    x : data[0],
                    y : data[19],
                    line: {simplify: false, color: 'rgb(152,66,245)'},
                    mode: 'lines'
                    }],
                    layout21,
                    config
                    )


                    Plotly.newPlot('graph2', [{
                    x : data[0],
                    y : data[20],
                    line: {simplify: false, color: 'rgb(152,66,245)'},
                    mode: 'lines'
                    }],
                    layout31,
                    config
                    )

                    Plotly.newPlot('graph5', [{
                    x : data[0],
                    y : data[21],
                    line: {simplify: false, color: 'rgb(152,66,245)'},
                    mode: 'lines'
                    }],
                    layout41,
                    config
                    )

                    Plotly.newPlot('graph3', [{
                    x : data[0],
                    y : data[22],
                    line: {simplify: false, color: 'rgb(152,66,245)'},
                    mode: 'lines'
                    }],
                    layout51,
                    config
                    )

                    Plotly.newPlot('graph6', [{
                    x : data[0],
                    y : data[23],
                    line: {simplify: false, color: 'rgb(152,66,245)'},
                    mode: 'lines'
                    }],
                    layout61,
                    config
                    )

                    Plotly.newPlot('graph7', [{
                    x : data[7],
                    y : data[30],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    name: "Response at m1"
                    },
                    {
                    x : data[7],
                    y : data[31],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Response at m2"
                    },
                    {
                    x : data[7],
                    y : data[34],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 1"
                    },
                    {
                    x : data[7],
                    y : data[35],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(255,127,15)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 2"
                    }],
                    layout71,
                    config
                    )

                    i=0;

                    Plotly.newPlot('graph9', [{
                    x : data[7],
                    y : data[32],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    name: "Response at m1"
                    },
                    {
                    x : data[7],
                    y : data[33],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Response at m2"    
                    },
                    {
                    x : data[7],
                    y : data[36],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 1"
                    },
                    {
                    x : data[7],
                    y : data[37],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(255,127,15)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 2"
                    }],
                    layout91,
                    config
                    )

                    i = 0;
                }

                // Plotting Accelerance
                if (data[17] == "3"){

                    Plotly.newPlot('graph', [{
                    title: "x1 Displacement: First Natural Frequency",
                    x : data[0],
                    y : data[24],
                    line: {simplify: false, color: 'rgb(76, 187, 23)'},
                    mode: 'lines'
                    }],
                    layout12,
                    config
                    )
                    

                    Plotly.newPlot('graph4', [{
                    x : data[0],
                    y : data[25],
                    line: {simplify: false, color: 'rgb(76, 187, 23)'},
                    mode: 'lines'
                    }],
                    layout22,
                    config
                    )


                    Plotly.newPlot('graph2', [{
                    x : data[0],
                    y : data[26],
                    line: {simplify: false, color: 'rgb(76, 187, 23)'},
                    mode: 'lines'
                    }],
                    layout32,
                    config
                    )

                    Plotly.newPlot('graph5', [{
                    x : data[0],
                    y : data[27],
                    line: {simplify: false, color: 'rgb(76, 187, 23)'},
                    mode: 'lines'
                    }],
                    layout42,
                    config
                    )

                    Plotly.newPlot('graph3', [{
                    x : data[0],
                    y : data[28],
                    line: {simplify: false, color: 'rgb(76, 187, 23)'},
                    mode: 'lines'
                    }],
                    layout52,
                    config
                    )

                    Plotly.newPlot('graph6', [{
                    x : data[0],
                    y : data[29],
                    line: {simplify: false, color: 'rgb(76, 187, 23)'},
                    mode: 'lines'
                    }],
                    layout62,
                    config
                    )

                    Plotly.newPlot('graph7', [{
                    x : data[7],
                    y : data[38],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    name: "Response at m1"
                    },
                    {
                    x : data[7],
                    y : data[39],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Response at m2"
                    },
                    {
                    x : data[7],
                    y : data[42],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 1"
                    },
                    {
                    x : data[7],
                    y : data[43],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(255,127,15)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 2"
                    }],
                    layout72,
                    config
                    )

                    i=0;

                    Plotly.newPlot('graph9', [{
                    x : data[7],
                    y : data[40],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    name: "Response at m1"
                    },
                    {
                    x : data[7],
                    y : data[41],
                    xaxis: 'x1',
                    yaxis: 'y1',
                    line: {simplify: false},
                    mode: 'lines',
                    name: "Response at m2"    
                    },
                    {
                    x : data[7],
                    y : data[44],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(0,62,116)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 1"
                    },
                    {
                    x : data[7],
                    y : data[45],
                    xaxis: 'x2',
                    yaxis: 'y2',
                    line: {simplify: false, color: 'rgb(255,127,15)'},
                    mode: 'lines',
                    showlegend: false
                    //name: "Phase Response 2"
                    }],
                    layout92,
                    config
                    )

                    i = 0;
                }

                /* Plotly.newPlot('graph7', [{
                x : data[7],
                y : data[8],
                line: {simplify: false, color: 'rgb(0,62,116)'},
                mode: 'lines',
                name: "Response 1"
                },
                {
                x : data[7],
                y : data[9],
                line: {simplify: false},
                mode: 'lines',
                name: "Response 2"
                }],
                layout7,
                config
                ) */

                i=0;
                
               /*  Plotly.newPlot('graph8', [{
                x : data[7],
                y : data[9],
                line: {simplify: false, color: 'rgb(0,62,116)'},
                mode: 'lines'
                }],
                layout8,
                config
                ) */

               /*  i=0;

                Plotly.newPlot('graph9', [{
                x : data[7],
                y : data[10],
                xaxis: 'x1',
                yaxis: 'y1',
                line: {simplify: false, color: 'rgb(0,62,116)'},
                mode: 'lines',
                name: "Response at m1"
                },
                {
                x : data[7],
                y : data[11],
                xaxis: 'x1',
                yaxis: 'y1',
                line: {simplify: false},
                mode: 'lines',
                name: "Response at m2"    
                },
                {
                x : data[7],
                y : data[15],
                xaxis: 'x2',
                yaxis: 'y2',
                line: {simplify: false, color: 'rgb(0,62,116)'},
                mode: 'lines',
                showlegend: false
                //name: "Phase Response 1"
                },
                {
                x : data[7],
                y : data[16],
                xaxis: 'x2',
                yaxis: 'y2',
                line: {simplify: false, color: 'rgb(255,127,15)'},
                mode: 'lines',
                showlegend: false
                //name: "Phase Response 2"
                }],
                layout9,
                config
                )

                i=0; */

                /* Plotly.newPlot('graph10', [{
                x : data[7],
                y : data[11],
                line: {simplify: false, color: 'rgb(0,62,116)'},
                mode: 'lines'
                }],
                layout10,
                config
                ) */

                i=0;
            }

            i++
        }

        update();
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
html{
    overflow: hidden;
}
.iv-pane-right{
    overflow: auto;
}
p.small {
  line-height: 1.5;
}
p.big {
  line-height: 1.5;
}
h5 {
  line-height: 10px;
}
#graph {
    z-index:-2;
}
@media screen and (orientation: portrait) {
    #graph {
        width:400px;
    }
}

/* @media screen and (orientation: landscape) {
    #graph {
        width:90%; height:400px;
    }
} */

@media screen and (orientation: landscape) {
    #graph {
        height:350px;
    }
    #graph2 {
        height: 350px;
    }
    #graph3 {
        height: 350px;
    }
    #graph4 {
        height: 350px;
    }
    #graph5 {
        height: 350px;
    }
    #graph6 {
        height: 350px;
    }
    #graph7 {
        height: 80vh;
    }
    #graph9 {
        height: 80vh;
    }

    #innerFlex1 {
        width:50%;
        min-width: 300px;
        flex-grow: 1;
    }
    #innerFlex2 {
        width: 50%;
        min-width: 300px;
        flex-grow: 2;
    }
    #flexContainer {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;

    }
}
</style>
